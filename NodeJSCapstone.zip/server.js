const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const pug = require("pug");

dotenv.config();

//------------------------Mongoose model setup------------------------
const userSchema = mongoose.Schema({
  email: { type: String, required: true, index: { unique: true } },
  password: { type: String, required: true },
});
const User = mongoose.model("User", userSchema);

//-------------------------Express App setup------------------------
const app = express();
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

//-----------------------------Express Routes---------------------------
app.post("/signin.html", (req, res) => {
  User.findOne({ email: req.body.email })
    .then((response) => {
      if (response) return bcrypt.compare(req.body.password, response.password);
      else {
        res.send("Invalid credentials");
        throw new Error("Username failure");
      }
    })
    .then((response) => {
      if (response) {
        const token = jwt.sign(
          { time: Date(), email: req.body.email },
          process.env.JWT_SECRET_KEY
        );
        res.send(pug.renderFile("signinSuccess.pug", { token }));
      } else res.send("Invalid credentials");
    })
    .catch((err) => {
      console.log(err.message);
    });
});

app.post("/signup.html", (req, res) => {
  if (req.body.email === "") {
    res.send("Empty email address field");
    return;
  }
  if (req.body.password.length < 5) {
    res.send("Password should be atleast 5 characters");
    return;
  }

  User.findOne({ email: req.body.email })
    .then((response) => {
      if (response) {
        res.send("Email address already registered");
        throw new Error("email already in use");
      } else {
        return bcrypt.hash(req.body.password, 10);
      }
    })
    .then((hash) => {
      const newUser = new User({ email: req.body.email, password: hash });
      return newUser.save();
    })
    .then((response) => {
      res.sendFile(__dirname + "/signupSuccess.html");
    })
    .catch((err) => {
      console.log(err.message);
    });
});

app.use((req, res, next) => {
  const token = req.header("authorization");
  if (token) {
    jwt.verify(token.slice(7), process.env.JWT_SECRET_KEY, (err, decoded) => {
      if (decoded) {
        req.body.email = decoded.email;
        next();
      } else {
        res.sendFile(__dirname + "./unauthorised.html");
      }
    });
  } else res.sendFile(__dirname + "/unauthorised.html");
});

app.use((req, res) => {
  res.send(pug.renderFile("authorised.pug", { email: req.body.email }));
});

//--------Starting server and connecting to database--------------------------
app.listen(process.env.PORT, "localhost", (err) => {
  if (err) console.log("Error: ", err);
  else {
    console.log("Server running on localhost:" + process.env.PORT);
  }
});

mongoose
  .connect("mongodb://127.0.0.1:27017/capstoneAksL")
  .then((response) => {
    console.log("Database connected");
  })
  .catch((err) => {
    console.log("Error in connecting to database: ", err);
  });
